import { ActivityCard } from "@/components/activity-card";
import { Badge, Card, PageShell } from "@/components/ui";
import { activities } from "@/lib/demo-data";

export default function HomePage() {
  return (
    <PageShell>
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div><Badge tone="mint">Discovery</Badge><h1 className="mt-3 text-4xl font-black">Nearby activities</h1><p className="mt-2 text-ink/70">Switch between card, list, and local map-style views. All actions work without gestures.</p></div>
        <div className="flex gap-2 rounded-full bg-white p-1 shadow-sm"><button className="rounded-full bg-ink px-4 py-2 text-sm font-bold text-white">Cards</button><button className="px-4 py-2 text-sm font-bold">List</button><button className="px-4 py-2 text-sm font-bold">Map</button></div>
      </div>
      <Card className="mt-6">
        <div className="grid gap-3 md:grid-cols-4 lg:grid-cols-8">
          {["Category", "Distance", "Date", "Type", "Group size", "Accessibility", "Difficulty", "Language"].map((filter) => <select key={filter} className="field"><option>{filter}</option><option>Any</option></select>)}
        </div>
      </Card>
      <div className="mt-6 grid gap-5 lg:grid-cols-3">
        {activities.map((activity) => <ActivityCard key={activity.id} activity={activity} />)}
      </div>
      <Card className="mt-6">
        <h2 className="text-xl font-black">Mock map</h2>
        <div className="mt-4 grid min-h-72 place-items-center rounded-2xl bg-[linear-gradient(135deg,#d9f2de_25%,#fff4cf_25%,#fff4cf_50%,#dbeafe_50%,#dbeafe_75%,#ffffff_75%)] bg-[length:80px_80px]">
          <p className="rounded-full bg-white px-5 py-3 font-bold shadow-soft">OpenStreetMap-compatible local preview</p>
        </div>
      </Card>
    </PageShell>
  );
}
