import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/current-user";

const blockSchema = z.object({ blockedId: z.string(), reason: z.string().max(400).optional() });

export async function POST(request: Request) {
  const user = await requireUser();
  const data = blockSchema.parse(await request.json());
  if (data.blockedId === user.id) return NextResponse.json({ error: "Cannot block yourself." }, { status: 400 });
  const block = await prisma.block.upsert({
    where: { blockerId_blockedId: { blockerId: user.id, blockedId: data.blockedId } },
    update: { reason: data.reason },
    create: { blockerId: user.id, blockedId: data.blockedId, reason: data.reason }
  });
  return NextResponse.json({ block });
}
