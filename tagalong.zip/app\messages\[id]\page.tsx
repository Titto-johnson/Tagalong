import { notFound } from "next/navigation";
import { Card, PageShell } from "@/components/ui";
import { conversations } from "@/lib/demo-data";

export default async function ConversationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const conversation = conversations.find((item) => item.id === id);
  if (!conversation) notFound();
  return (
    <PageShell narrow>
      <h1 className="text-3xl font-black">{conversation.title}</h1>
      <Card className="mt-6 min-h-[420px]">
        <div className="space-y-3">{conversation.messages.map((message, index) => <p key={message} className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${index % 2 ? "ml-auto bg-coral text-white" : "bg-mint"}`}>{message}</p>)}</div>
      </Card>
      <form className="mt-4 flex gap-2"><input className="field" placeholder="Message accepted participants" /><button className="rounded-full bg-ink px-5 py-3 text-sm font-bold text-white">Send</button></form>
    </PageShell>
  );
}
