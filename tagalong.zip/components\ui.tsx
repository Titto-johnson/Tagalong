import Link from "next/link";
import { clsx } from "clsx";
import type { ReactNode } from "react";
import { ArrowRight, Ban, Bell, CalendarDays, Flag, Heart, MapPin, MessageCircle, ShieldCheck, Users } from "lucide-react";

export function Logo() {
  return (
    <Link href="/" className="inline-flex items-center gap-2 font-black tracking-tight text-ink">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-ink text-white">T</span>
      <span>TAGALONG</span>
    </Link>
  );
}

export function ButtonLink({ href, children, variant = "primary" }: { href: string; children: ReactNode; variant?: "primary" | "secondary" | "ghost" }) {
  return (
    <Link
      href={href}
      className={clsx(
        "inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-bold transition",
        variant === "primary" && "bg-coral text-white shadow-soft hover:bg-[#df5e39]",
        variant === "secondary" && "bg-ink text-white hover:bg-moss",
        variant === "ghost" && "bg-white text-ink ring-1 ring-ink/10 hover:bg-mint"
      )}
    >
      {children}
      {variant !== "ghost" && <ArrowRight size={17} aria-hidden />}
    </Link>
  );
}

export function PageShell({ children, narrow = false }: { children: ReactNode; narrow?: boolean }) {
  return (
    <main className="min-h-screen bg-[#fbfbf7] text-ink">
      <TopNav />
      <div className={clsx("mx-auto w-full px-4 py-8 sm:px-6 lg:px-8", narrow ? "max-w-4xl" : "max-w-7xl")}>{children}</div>
    </main>
  );
}

export function TopNav() {
  return (
    <header className="sticky top-0 z-30 border-b border-ink/10 bg-[#fbfbf7]/95 backdrop-blur">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8" aria-label="Primary">
        <Logo />
        <div className="hidden items-center gap-2 md:flex">
          {["home", "profiles", "messages", "my-activities", "settings"].map((item) => (
            <Link key={item} href={`/${item}`} className="rounded-full px-3 py-2 text-sm font-semibold text-ink/75 hover:bg-mint hover:text-ink">
              {item.replace("-", " ")}
            </Link>
          ))}
        </div>
        <ButtonLink href="/create-activity" variant="secondary">Create</ButtonLink>
      </nav>
    </header>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={clsx("rounded-2xl border border-ink/10 bg-white p-5 shadow-sm", className)}>{children}</section>;
}

export function Badge({ children, tone = "mint" }: { children: ReactNode; tone?: "mint" | "sky" | "wheat" | "coral" | "ink" }) {
  return (
    <span
      className={clsx(
        "inline-flex items-center rounded-full px-3 py-1 text-xs font-bold",
        tone === "mint" && "bg-mint text-ink",
        tone === "sky" && "bg-sky text-ink",
        tone === "wheat" && "bg-wheat text-ink",
        tone === "coral" && "bg-coral/15 text-[#a64226]",
        tone === "ink" && "bg-ink text-white"
      )}
    >
      {children}
    </span>
  );
}

export function SafetyNotice({ help = false }: { help?: boolean }) {
  return (
    <Card className="border-coral/30 bg-[#fff7f2]">
      <div className="flex gap-3">
        <ShieldCheck className="mt-1 shrink-0 text-coral" aria-hidden />
        <div>
          <h2 className="font-bold">Safety first</h2>
          <p className="mt-1 text-sm leading-6 text-ink/75">
            Meet in public places, tell someone where you are going, arrange your own transportation, avoid sending money, protect personal information, and contact local emergency services during emergencies.
          </p>
          {help && (
            <p className="mt-2 text-sm font-semibold text-[#9c3a22]">
              TAGALONG is not an emergency, medical, transportation, caregiving, or professional-services provider.
            </p>
          )}
        </div>
      </div>
    </Card>
  );
}

export function ActivityActions() {
  return (
    <div className="grid grid-cols-4 gap-2">
      <button className="rounded-xl bg-coral px-3 py-2 text-sm font-bold text-white">Join</button>
      <button aria-label="Save activity" className="grid place-items-center rounded-xl bg-mint py-2 text-ink"><Heart size={18} /></button>
      <button aria-label="Message host" className="grid place-items-center rounded-xl bg-sky py-2 text-ink"><MessageCircle size={18} /></button>
      <button aria-label="Report activity" className="grid place-items-center rounded-xl bg-wheat py-2 text-ink"><Flag size={18} /></button>
    </div>
  );
}

export const Icons = { MapPin, CalendarDays, Users, Bell, Ban };
