import { Badge, Card, SafetyNotice } from "@/components/ui";
import { isDemoMode } from "@/lib/demo-mode";

export function AuthForm({ mode }: { mode: "sign-in" | "sign-up" }) {
  const isSignUp = mode === "sign-up";
  const demoMode = isDemoMode();
  return (
    <Card className="mx-auto max-w-lg">
      <h1 className="text-3xl font-black">{isSignUp ? "Create your account" : "Welcome back"}</h1>
      <p className="mt-2 text-sm leading-6 text-ink/70">{isSignUp ? "Adults 18+ can join TAGALONG for activity discovery, requests, and messaging." : "Sign in to manage activities, requests, and conversations."}</p>
      {demoMode && (
        <div className="mt-4 rounded-2xl bg-mint p-4">
          <p className="text-sm font-bold">Development demo accounts</p>
          <p className="mt-1 text-sm text-ink/70">Host: host@tagalong.test / Password123!</p>
          <p className="text-sm text-ink/70">Participant: participant@tagalong.test / Password123!</p>
        </div>
      )}
      <form className="mt-6 space-y-4" action={demoMode ? "/api/demo-auth" : isSignUp ? "/api/register" : "/api/auth/callback/credentials"} method="post">
        <input type="hidden" name="mode" value={mode} />
        {isSignUp && <input className="field" name="name" placeholder="Display name" required />}
        <input className="field" name="email" placeholder="Email" type="email" required />
        <input className="field" name="password" placeholder="Password" type="password" minLength={8} required />
        {isSignUp && (
          <label className="flex items-start gap-3 text-sm text-ink/75">
            <input className="mt-1" type="checkbox" name="adult" required />
            I confirm I am 18 or older and agree to follow the community and safety guidelines.
          </label>
        )}
        <button className="w-full rounded-full bg-coral px-5 py-3 text-sm font-bold text-white">{isSignUp ? "Create account" : "Sign in"}</button>
      </form>
      <div className="mt-4 text-sm">
        {isSignUp ? "Already have an account? " : "New to TAGALONG? "}
        <a className="font-bold text-coral" href={isSignUp ? "/sign-in" : "/sign-up"}>{isSignUp ? "Sign in" : "Create one"}</a>
      </div>
    </Card>
  );
}

export function ProfileForm() {
  return (
    <Card>
      <h1 className="text-3xl font-black">Complete your profile</h1>
      <p className="mt-2 text-ink/70">Only approximate city-level location is shown publicly.</p>
      <form className="mt-6 grid gap-4 md:grid-cols-2">
        {["Display name", "Age", "Approximate city", "Languages"].map((label) => <label key={label} className="space-y-2"><span className="label">{label}</span><input className="field" placeholder={label} /></label>)}
        <label className="space-y-2 md:col-span-2"><span className="label">Biography</span><textarea className="field min-h-28" placeholder="Share activity interests, boundaries, and what makes a good meetup." /></label>
        <label className="space-y-2"><span className="label">Interests</span><input className="field" placeholder="Coffee, hiking, volunteering" /></label>
        <label className="space-y-2"><span className="label">Availability</span><input className="field" placeholder="Weeknights, weekends" /></label>
        <label className="space-y-2 md:col-span-2"><span className="label">Accessibility information</span><textarea className="field min-h-24" /></label>
        <button className="rounded-full bg-coral px-5 py-3 text-sm font-bold text-white md:col-span-2">Save profile</button>
      </form>
    </Card>
  );
}

export function ActivityForm({ editing = false }: { editing?: boolean }) {
  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
      <Card>
        <h1 className="text-3xl font-black">{editing ? "Edit activity" : "Create an activity"}</h1>
        <form className="mt-6 grid gap-4 md:grid-cols-2">
          <label className="space-y-2"><span className="label">Category</span><select className="field"><option>Entertainment and Errands</option><option>Help and Volunteer</option><option>Adventure</option></select></label>
          <label className="space-y-2"><span className="label">Activity type</span><input className="field" placeholder="Movie, hiking, grocery trip" /></label>
          <label className="space-y-2 md:col-span-2"><span className="label">Title</span><input className="field" placeholder="Clear, specific activity title" /></label>
          <label className="space-y-2 md:col-span-2"><span className="label">Description</span><textarea className="field min-h-28" /></label>
          <label className="space-y-2"><span className="label">Date and time</span><input className="field" type="datetime-local" /></label>
          <label className="space-y-2"><span className="label">Approximate meeting area</span><input className="field" placeholder="Downtown Austin" /></label>
          <label className="space-y-2"><span className="label">Maximum participants</span><input className="field" type="number" min={1} max={24} /></label>
          <label className="space-y-2"><span className="label">Cost</span><select className="field"><option>Free</option><option>Paid</option><option>Split costs</option></select></label>
          <label className="space-y-2 md:col-span-2"><span className="label">Accessibility details</span><textarea className="field min-h-24" /></label>
          <label className="space-y-2"><span className="label">Adventure difficulty</span><select className="field"><option>Not applicable</option><option>Easy</option><option>Moderate</option><option>Challenging</option><option>Hard</option></select></label>
          <label className="space-y-2"><span className="label">Expected duration</span><input className="field" placeholder="2 hours" /></label>
          <label className="space-y-2 md:col-span-2"><span className="label">Equipment and safety notes</span><textarea className="field min-h-24" /></label>
          <button className="rounded-full bg-coral px-5 py-3 text-sm font-bold text-white md:col-span-2">{editing ? "Save changes" : "Preview and publish"}</button>
        </form>
      </Card>
      <div className="space-y-4">
        <SafetyNotice help />
        <Card><Badge tone="sky">Preview</Badge><h2 className="mt-3 text-xl font-black">Your activity card</h2><p className="mt-2 text-sm text-ink/70">Exact meeting details should be shared only after a request is accepted.</p></Card>
      </div>
    </div>
  );
}
