import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/current-user";
import { profileSchema } from "@/lib/security";

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const data = profileSchema.parse(await request.json());
    const profile = await prisma.profile.upsert({
      where: { userId: user.id },
      update: data,
      create: { ...data, userId: user.id, preferredCategories: ["ENTERTAINMENT_ERRANDS", "HELP_VOLUNTEER", "ADVENTURE"] }
    });
    return NextResponse.json({ profile });
  } catch {
    return NextResponse.json({ error: "Profile could not be saved." }, { status: 400 });
  }
}
