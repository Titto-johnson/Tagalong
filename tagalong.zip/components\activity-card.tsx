import Image from "next/image";
import Link from "next/link";
import { ActivityActions, Badge, Card, Icons } from "@/components/ui";
import { profiles } from "@/lib/demo-data";

type Activity = {
  id: string;
  hostId: string;
  category: string;
  activityType: string;
  title: string;
  description: string;
  startsAt: string;
  location: string;
  maximumParticipants: number;
  joined: number;
  distance: number;
  image: string;
  difficulty?: string;
  duration?: string;
};

export function ActivityCard({ activity }: { activity: Activity }) {
  const host = profiles.find((profile) => profile.id === activity.hostId);
  return (
    <Card className="overflow-hidden p-0">
      <div className="relative h-48">
        <Image src={activity.image} alt="" fill className="object-cover" />
      </div>
      <div className="space-y-4 p-5">
        <div className="flex flex-wrap gap-2">
          <Badge>{activity.activityType}</Badge>
          <Badge tone="sky">{activity.distance} mi away</Badge>
          {activity.difficulty && <Badge tone="wheat">{activity.difficulty.toLowerCase()}</Badge>}
        </div>
        <div>
          <Link href={`/activities/${activity.id}`} className="text-xl font-black hover:text-coral">{activity.title}</Link>
          <p className="mt-2 line-clamp-2 text-sm leading-6 text-ink/70">{activity.description}</p>
        </div>
        <dl className="grid grid-cols-2 gap-3 text-sm text-ink/75">
          <div className="flex items-center gap-2"><Icons.CalendarDays size={16} />{new Date(activity.startsAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</div>
          <div className="flex items-center gap-2"><Icons.MapPin size={16} />{activity.location}</div>
          <div className="flex items-center gap-2"><Icons.Users size={16} />{activity.maximumParticipants - activity.joined} open spaces</div>
          <div>Hosted by <Link className="font-bold" href={`/profile/${host?.id ?? "demo"}`}>{host?.displayName}</Link></div>
        </dl>
        <ActivityActions />
      </div>
    </Card>
  );
}
