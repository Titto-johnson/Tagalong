import { milesBetween } from "@/lib/distance";

export const demoUser = {
  id: "demo-participant",
  displayName: "Maya Chen",
  age: 31,
  approximateCity: "Austin, TX",
  latitude: 30.2672,
  longitude: -97.7431,
  interests: ["coffee", "volunteering", "hiking", "museums"],
  languages: ["English", "Spanish"],
  availability: ["Weeknights", "Saturday mornings"],
  image: "/avatars/maya.svg"
};

export const profiles = [
  demoUser,
  { id: "host-1", displayName: "Jordan Lee", age: 34, approximateCity: "Austin, TX", latitude: 30.285, longitude: -97.741, interests: ["film", "cycling", "local food"], languages: ["English"], availability: ["Evenings"], image: "/avatars/jordan.svg" },
  { id: "host-2", displayName: "Sam Rivera", age: 42, approximateCity: "Round Rock, TX", latitude: 30.508, longitude: -97.678, interests: ["community volunteering", "technology help"], languages: ["English", "Spanish"], availability: ["Weekends"], image: "/avatars/sam.svg" },
  { id: "host-3", displayName: "Nina Patel", age: 29, approximateCity: "Austin, TX", latitude: 30.243, longitude: -97.786, interests: ["trail runs", "photography", "camping"], languages: ["English", "Hindi"], availability: ["Early mornings"], image: "/avatars/nina.svg" }
];

export const activities = [
  { id: "a1", hostId: "host-1", category: "ENTERTAINMENT_ERRANDS", activityType: "Movie", title: "Indie movie at Violet Crown", description: "I am planning to watch a movie tonight and would enjoy easy conversation before the show.", startsAt: "2026-08-03T19:30:00.000Z", location: "Downtown Austin", latitude: 30.265, longitude: -97.747, maximumParticipants: 3, joined: 1, costType: "PAID", accessibility: "Theater has accessible seating.", image: "/activity/movie.svg" },
  { id: "a2", hostId: "host-2", category: "HELP_VOLUNTEER", activityType: "Technology assistance", title: "Help neighbors set up phones", description: "Volunteer session at a community center helping adults with basic device settings and video calls.", startsAt: "2026-08-05T16:00:00.000Z", location: "Round Rock Community Center", latitude: 30.509, longitude: -97.679, maximumParticipants: 6, joined: 4, costType: "FREE", accessibility: "Step-free entrance and seating.", image: "/activity/volunteer.svg" },
  { id: "a3", hostId: "host-3", category: "ADVENTURE", activityType: "Hiking", title: "Sunrise hike at Barton Creek", description: "Moderate-paced hike with photo stops. Bring water and trail shoes.", startsAt: "2026-08-06T12:00:00.000Z", location: "Barton Creek Greenbelt", latitude: 30.245, longitude: -97.802, maximumParticipants: 5, joined: 2, costType: "FREE", difficulty: "MODERATE", duration: "2.5 hours", equipment: "Water, grippy shoes, sun protection.", safetyNotes: "Meet at the public trailhead. We will stay together and turn back in heavy rain.", image: "/activity/hike.svg" },
  { id: "a4", hostId: "host-1", category: "ENTERTAINMENT_ERRANDS", activityType: "Grocery trip", title: "Central Market grocery run", description: "Picking up ingredients for the week and open to sharing recipe ideas while shopping.", startsAt: "2026-08-04T22:00:00.000Z", location: "North Lamar", latitude: 30.309, longitude: -97.739, maximumParticipants: 2, joined: 0, costType: "FREE", accessibility: "Wide aisles and accessible parking.", image: "/activity/errand.svg" }
].map((activity) => ({
  ...activity,
  distance: Number(milesBetween(demoUser, { latitude: activity.latitude, longitude: activity.longitude }).toFixed(1))
}));

export const requests = [
  { id: "r1", activityTitle: "Indie movie at Violet Crown", requester: "Maya Chen", status: "PENDING", intro: "I like small theaters and would be glad to meet in the lobby first." },
  { id: "r2", activityTitle: "Sunrise hike at Barton Creek", requester: "Owen Brooks", status: "ACCEPTED", intro: "Comfortable with moderate trails and can bring an extra first-aid kit." }
];

export const conversations = [
  { id: "c1", title: "Sunrise hike at Barton Creek", participant: "Nina Patel", messages: ["Welcome aboard. We will meet at the main trailhead.", "Sounds good. I will bring water and a small first-aid kit."] },
  { id: "c2", title: "Technology help session", participant: "Sam Rivera", messages: ["Thanks for joining the volunteer session.", "Happy to help. I can cover video call setup."] }
];
