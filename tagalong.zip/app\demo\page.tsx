import { Badge, Card, PageShell } from "@/components/ui";

const steps = ["User problem", "TAGALONG solution", "Target users", "Product categories", "Discovery experience", "Creating an activity", "Requesting to join", "Host selection", "Messaging", "Trust and safety", "Community impact", "Future roadmap"];

export default function DemoPage() {
  return (
    <PageShell>
      <Badge tone="wheat">Investor walkthrough</Badge>
      <h1 className="mt-3 text-4xl font-black">TAGALONG demo story</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {steps.map((step, index) => (
          <Card key={step}><Badge tone="sky">Step {index + 1}</Badge><h2 className="mt-3 text-xl font-black">{step}</h2><p className="mt-2 text-sm leading-6 text-ink/70">{step === "Future roadmap" ? "MVP: discovery, posting, requests, profiles, messaging, moderation. Phase 2: identity verification, groups, recommendations. Phase 3: partnerships, event integrations, reputation improvements." : "A realistic demo checkpoint for showing how TAGALONG moves from everyday loneliness or coordination friction into safer local companionship."}</p></Card>
        ))}
      </div>
    </PageShell>
  );
}
