import { NextResponse } from "next/server";
import { isDemoMode } from "@/lib/demo-mode";

export async function POST(request: Request) {
  if (!isDemoMode()) {
    return NextResponse.json({ error: "Demo authentication is disabled." }, { status: 404 });
  }

  const body = await request.formData();
  const mode = body.get("mode");
  const target = mode === "sign-up" ? "/onboarding" : "/home";
  const response = NextResponse.redirect(new URL(target, request.url), { status: 303 });
  response.cookies.set("tagalong-demo-session", "true", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 8
  });
  return response;
}
