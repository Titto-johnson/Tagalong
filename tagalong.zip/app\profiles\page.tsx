import Image from "next/image";
import Link from "next/link";
import { Badge, Card, PageShell } from "@/components/ui";
import { profiles } from "@/lib/demo-data";

export default function ProfilesPage() {
  return (
    <PageShell>
      <h1 className="text-4xl font-black">Nearby profiles</h1>
      <div className="mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        {profiles.map((profile) => (
          <Card key={profile.id}>
            <Image src={profile.image} alt="" width={96} height={96} className="h-20 w-20 rounded-2xl object-cover" />
            <h2 className="mt-4 text-xl font-black"><Link href={`/profile/${profile.id}`}>{profile.displayName}</Link></h2>
            <p className="text-sm text-ink/70">{profile.age} · {profile.approximateCity}</p>
            <div className="mt-3 flex flex-wrap gap-2">{profile.interests.slice(0, 3).map((interest) => <Badge key={interest}>{interest}</Badge>)}</div>
          </Card>
        ))}
      </div>
    </PageShell>
  );
}
