import Link from "next/link";
import { Card, PageShell } from "@/components/ui";
import { conversations } from "@/lib/demo-data";

export default function InboxPage() {
  return <PageShell><h1 className="text-4xl font-black">Messaging inbox</h1><div className="mt-6 grid gap-4">{conversations.map((conversation) => <Card key={conversation.id}><Link href={`/messages/${conversation.id}`} className="text-xl font-black">{conversation.title}</Link><p className="mt-2 text-ink/70">Accepted participant: {conversation.participant}</p></Card>)}</div></PageShell>;
}
