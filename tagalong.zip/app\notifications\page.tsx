import { Card, Icons, PageShell } from "@/components/ui";

export default function NotificationsPage() {
  return <PageShell narrow><h1 className="text-4xl font-black">Notifications</h1><div className="mt-6 space-y-3">{["Your hike request was accepted.", "New request for Indie movie at Violet Crown.", "Safety reminder: keep exact meeting details private until accepted."].map((n) => <Card key={n}><div className="flex gap-3"><Icons.Bell /><p className="font-semibold">{n}</p></div></Card>)}</div></PageShell>;
}
