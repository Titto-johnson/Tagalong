import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/current-user";
import { rateLimit, sanitizeText } from "@/lib/security";

const messageSchema = z.object({ body: z.string().min(1).max(1600).transform(sanitizeText) });

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireUser();
  const { id } = await params;
  const member = await prisma.conversationMember.findUnique({ where: { conversationId_userId: { conversationId: id, userId: user.id } } });
  if (!member) return NextResponse.json({ error: "Not authorized." }, { status: 403 });
  const messages = await prisma.message.findMany({ where: { conversationId: id }, orderBy: { createdAt: "asc" }, take: 100 });
  return NextResponse.json({ messages });
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    rateLimit(`message:${user.id}`, 30, 60_000);
    const member = await prisma.conversationMember.findUnique({ where: { conversationId_userId: { conversationId: id, userId: user.id } } });
    if (!member) return NextResponse.json({ error: "Not authorized." }, { status: 403 });
    const data = messageSchema.parse(await request.json());
    const message = await prisma.message.create({ data: { conversationId: id, senderId: user.id, body: data.body } });
    return NextResponse.json({ message }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Message could not be sent." }, { status: 400 });
  }
}
