import { Card, PageShell, SafetyNotice } from "@/components/ui";

export default function SafetyPage() {
  return (
    <PageShell narrow>
      <h1 className="text-4xl font-black">Community and safety guidelines</h1>
      <div className="mt-6 space-y-4">
        <SafetyNotice help />
        <Card>
          <h2 className="text-xl font-black">Not allowed</h2>
          <p className="mt-3 leading-7 text-ink/70">Emergencies, medical procedures, prescription handling, dangerous transportation, childcare, financial transactions, and regulated professional services are prohibited.</p>
        </Card>
        <Card>
          <h2 className="text-xl font-black">Before joining</h2>
          <p className="mt-3 leading-7 text-ink/70">Review the host profile, keep public first meetings, use the in-app report and block controls, and leave any situation that feels unsafe.</p>
        </Card>
      </div>
    </PageShell>
  );
}
