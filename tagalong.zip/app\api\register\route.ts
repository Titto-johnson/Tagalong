import { hash } from "bcryptjs";
import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/security";

const registerSchema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email(),
  password: z.string().min(8),
  adult: z.string().optional()
});

export async function POST(request: Request) {
  try {
    const body = Object.fromEntries((await request.formData()).entries());
    const data = registerSchema.parse(body);
    if (!data.adult) throw new Error("Adults 18 or older only.");
    rateLimit(`register:${data.email}`, 3, 60_000);
    await prisma.user.create({
      data: {
        name: data.name.trim(),
        email: data.email.toLowerCase(),
        passwordHash: await hash(data.password, 12),
        safetyAcknowledgments: { create: { version: "mvp-2026-07" } }
      }
    });
    return NextResponse.redirect(new URL("/onboarding", request.url), { status: 303 });
  } catch {
    return NextResponse.json({ error: "Unable to register with the provided information." }, { status: 400 });
  }
}
