import { ProfileForm } from "@/components/forms";
import { PageShell } from "@/components/ui";

export default function OnboardingPage() {
  return <PageShell><ProfileForm /></PageShell>;
}
