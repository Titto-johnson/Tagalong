import { Card, PageShell, SafetyNotice } from "@/components/ui";

export default function ReportPage() {
  return <PageShell narrow><h1 className="text-4xl font-black">Report a user or activity</h1><div className="mt-6 space-y-4"><SafetyNotice /><Card><form className="space-y-4"><select className="field"><option>Harassment or abusive behavior</option><option>Unsafe activity</option><option>Prohibited service request</option><option>Spam or scam</option></select><textarea className="field min-h-32" placeholder="Describe what happened without sharing private information." /><button className="rounded-full bg-coral px-5 py-3 text-sm font-bold text-white">Submit report</button></form></Card></div></PageShell>;
}
