import Image from "next/image";
import { notFound } from "next/navigation";
import { Badge, Card, PageShell } from "@/components/ui";
import { profiles } from "@/lib/demo-data";

export default async function UserProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const profile = profiles.find((item) => item.id === id);
  if (!profile) notFound();
  return (
    <PageShell narrow>
      <Card>
        <Image src={profile.image} alt="" width={120} height={120} className="h-28 w-28 rounded-3xl object-cover" />
        <h1 className="mt-5 text-4xl font-black">{profile.displayName}</h1>
        <p className="mt-1 text-ink/70">{profile.age} · {profile.approximateCity} · member since 2026</p>
        <p className="mt-5 leading-7 text-ink/75">Friendly TAGALONG community member interested in low-pressure activities, clear plans, and public meeting places.</p>
        <div className="mt-5 flex flex-wrap gap-2">{profile.interests.map((interest) => <Badge key={interest}>{interest}</Badge>)}</div>
        <dl className="mt-6 grid gap-4 md:grid-cols-3">
          <div><dt className="font-bold">Languages</dt><dd>{profile.languages.join(", ")}</dd></div>
          <div><dt className="font-bold">Availability</dt><dd>{profile.availability.join(", ")}</dd></div>
          <div><dt className="font-bold">Community rating</dt><dd>4.8 sample</dd></div>
        </dl>
      </Card>
    </PageShell>
  );
}
