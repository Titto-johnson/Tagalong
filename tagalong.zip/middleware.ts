import { NextResponse, type NextRequest } from "next/server";
import { isDemoMode } from "@/lib/demo-mode";

const protectedPrefixes = [
  "/home",
  "/profiles",
  "/activities",
  "/requests",
  "/profile",
  "/messages",
  "/notifications",
  "/saved",
  "/my-activities",
  "/settings",
  "/privacy",
  "/blocked",
  "/report",
  "/admin"
];

export function middleware(request: NextRequest) {
  const isProtected = protectedPrefixes.some((prefix) => request.nextUrl.pathname.startsWith(prefix));
  const demoMode = isDemoMode();
  const hasSessionCookie = request.cookies.has("authjs.session-token") || request.cookies.has("__Secure-authjs.session-token") || request.cookies.has("tagalong-demo-session");
  if (isProtected && !demoMode && !hasSessionCookie) {
    const signInUrl = new URL("/sign-in", request.url);
    signInUrl.searchParams.set("callbackUrl", request.nextUrl.pathname);
    return NextResponse.redirect(signInUrl);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"]
};
