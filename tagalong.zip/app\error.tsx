"use client";

import { ButtonLink, PageShell } from "@/components/ui";

export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <PageShell narrow>
      <div className="py-20 text-center">
        <h1 className="text-5xl font-black">Something went wrong</h1>
        <p className="mt-4 text-ink/70">The request could not be completed safely. Try again or return to discovery.</p>
        <div className="mt-8 flex justify-center gap-3">
          <button onClick={reset} className="rounded-full bg-coral px-5 py-3 text-sm font-bold text-white">Try again</button>
          <ButtonLink href="/home" variant="ghost">Discovery</ButtonLink>
        </div>
      </div>
    </PageShell>
  );
}
