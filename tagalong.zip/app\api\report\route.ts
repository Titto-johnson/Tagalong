import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/current-user";
import { rateLimit, sanitizeText } from "@/lib/security";

const reportSchema = z.object({
  reportedUserId: z.string().optional(),
  activityId: z.string().optional(),
  category: z.string().min(2).max(80).transform(sanitizeText),
  details: z.string().min(10).max(1600).transform(sanitizeText)
});

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    rateLimit(`report:${user.id}`, 5, 60_000);
    const data = reportSchema.parse(await request.json());
    const report = await prisma.report.create({ data: { ...data, reporterId: user.id } });
    return NextResponse.json({ report }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Report could not be submitted." }, { status: 400 });
  }
}
