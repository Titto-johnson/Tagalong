import { ActivityForm } from "@/components/forms";
import { PageShell } from "@/components/ui";

export default function CreateActivityPage() {
  return <PageShell><ActivityForm /></PageShell>;
}
