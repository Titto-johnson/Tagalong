import { z } from "zod";

const prohibitedHelpTerms = [
  "emergency",
  "medical procedure",
  "prescription",
  "medication",
  "childcare",
  "babysit",
  "send money",
  "loan",
  "ambulance",
  "dangerous ride"
];

export function sanitizeText(value: string) {
  return value.replace(/[<>]/g, "").trim();
}

export function containsProhibitedHelpRequest(input: string) {
  const normalized = input.toLowerCase();
  return prohibitedHelpTerms.some((term) => normalized.includes(term));
}

export function assertAdult(age: number) {
  if (age < 18) {
    throw new Error("TAGALONG is available only to adults 18 or older.");
  }
}

export const activityBaseSchema = z.object({
  category: z.enum(["ENTERTAINMENT_ERRANDS", "HELP_VOLUNTEER", "ADVENTURE"]),
  activityType: z.string().min(2).max(80).transform(sanitizeText),
  title: z.string().min(6).max(120).transform(sanitizeText),
  description: z.string().min(20).max(1800).transform(sanitizeText),
  startsAt: z.coerce.date(),
  approximateLocationLabel: z.string().min(2).max(120).transform(sanitizeText),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  maximumParticipants: z.number().int().min(1).max(24),
  costType: z.enum(["FREE", "PAID", "SPLIT"]).default("FREE"),
  accessibilityDetails: z.string().max(600).optional(),
  equipmentDetails: z.string().max(600).optional(),
  difficulty: z.enum(["EASY", "MODERATE", "CHALLENGING", "HARD"]).optional(),
  durationMinutes: z.number().int().min(15).max(10080).optional(),
  safetyNotes: z.string().max(900).optional()
});

export const activitySchema = activityBaseSchema.superRefine((value, ctx) => {
  if (value.category === "HELP_VOLUNTEER" && containsProhibitedHelpRequest(`${value.title} ${value.description}`)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["description"],
      message: "Help and Volunteer posts cannot involve emergencies, medical care, prescriptions, childcare, financial transactions, or regulated services."
    });
  }
  if (value.category === "ADVENTURE" && (!value.difficulty || !value.durationMinutes || !value.safetyNotes)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["safetyNotes"],
      message: "Adventure posts require difficulty, duration, and safety notes."
    });
  }
});

export const profileSchema = z.object({
  displayName: z.string().min(2).max(80).transform(sanitizeText),
  age: z.number().int().min(18).max(110),
  biography: z.string().min(20).max(900).transform(sanitizeText),
  approximateCity: z.string().min(2).max(100).transform(sanitizeText),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  interests: z.array(z.string().min(2).max(40)).min(1).max(12),
  languages: z.array(z.string().min(2).max(40)).min(1).max(8),
  availability: z.array(z.string().min(2).max(40)).min(1).max(10),
  accessibilityInformation: z.string().max(600).optional()
});

const buckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, limit = 10, windowMs = 60_000) {
  const now = Date.now();
  const current = buckets.get(key);
  if (!current || current.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  current.count += 1;
  if (current.count > limit) {
    throw new Error("Too many attempts. Please wait and try again.");
  }
}
