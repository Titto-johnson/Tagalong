import { Card, PageShell } from "@/components/ui";

export default function PrivacySettingsPage() {
  return <PageShell narrow><h1 className="text-4xl font-black">Privacy settings</h1><Card className="mt-6"><div className="space-y-4">{["Show age on profile", "Show approximate city", "Allow activity recommendations", "Hide from nearby profiles"].map((item) => <label key={item} className="flex items-center justify-between gap-4"><span className="font-semibold">{item}</span><input type="checkbox" defaultChecked={item !== "Hide from nearby profiles"} /></label>)}</div></Card></PageShell>;
}
