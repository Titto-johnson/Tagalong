import { AuthForm } from "@/components/forms";
import { PageShell } from "@/components/ui";

export default function SignUpPage() {
  return <PageShell narrow><AuthForm mode="sign-up" /></PageShell>;
}
