import type { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/current-user";

const decisionSchema = z.object({ status: z.enum(["ACCEPTED", "DECLINED"]) });

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    const decision = decisionSchema.parse(await request.json());
    const joinRequest = await prisma.activityRequest.findUnique({ where: { id }, include: { activity: true } });
    if (!joinRequest || joinRequest.activity.hostId !== user.id) return NextResponse.json({ error: "Not authorized." }, { status: 403 });
    const result = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      const updated = await tx.activityRequest.update({ where: { id }, data: { status: decision.status } });
      if (decision.status === "ACCEPTED") {
        const conversation = await tx.conversation.upsert({
          where: { id: joinRequest.activityId },
          update: {},
          create: { id: joinRequest.activityId, activityId: joinRequest.activityId }
        });
        await tx.activityParticipant.upsert({ where: { activityId_userId: { activityId: joinRequest.activityId, userId: joinRequest.requesterId } }, update: { removedAt: null }, create: { activityId: joinRequest.activityId, userId: joinRequest.requesterId } });
        await tx.conversationMember.upsert({ where: { conversationId_userId: { conversationId: conversation.id, userId: user.id } }, update: {}, create: { conversationId: conversation.id, userId: user.id } });
        await tx.conversationMember.upsert({ where: { conversationId_userId: { conversationId: conversation.id, userId: joinRequest.requesterId } }, update: {}, create: { conversationId: conversation.id, userId: joinRequest.requesterId } });
      }
      await tx.notification.create({ data: { userId: joinRequest.requesterId, title: `Request ${decision.status.toLowerCase()}`, body: `Your request for ${joinRequest.activity.title} was ${decision.status.toLowerCase()}.` } });
      return updated;
    });
    return NextResponse.json({ request: result });
  } catch {
    return NextResponse.json({ error: "Request could not be updated." }, { status: 400 });
  }
}
