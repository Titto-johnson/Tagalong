import { ProfileForm } from "@/components/forms";
import { PageShell } from "@/components/ui";

export default function EditProfilePage() {
  return <PageShell><ProfileForm /></PageShell>;
}
