import { ActivityCard } from "@/components/activity-card";
import { PageShell, SafetyNotice } from "@/components/ui";
import { activities } from "@/lib/demo-data";

export default function HelpVolunteerPage() {
  return <PageShell><h1 className="text-4xl font-black">Help and Volunteer</h1><div className="mt-6"><SafetyNotice help /></div><div className="mt-6 grid gap-5 lg:grid-cols-3">{activities.filter((a) => a.category === "HELP_VOLUNTEER").map((a) => <ActivityCard key={a.id} activity={a} />)}</div></PageShell>;
}
