import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { isDemoMode } from "@/lib/demo-mode";

export async function getCurrentUser() {
  const session = await auth();
  if (session?.user?.id) {
    const user = await prisma.user.findUnique({ where: { id: session.user.id } });
    if (user && !user.suspendedAt) return user;
  }
  if (isDemoMode()) {
    return prisma.user.findFirst({ where: { email: "participant@tagalong.test" } });
  }
  return null;
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new Error("Authentication required.");
  return user;
}
