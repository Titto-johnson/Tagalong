import { Card, Icons, PageShell } from "@/components/ui";

export default function BlockedUsersPage() {
  return <PageShell narrow><h1 className="text-4xl font-black">Blocked users</h1><Card className="mt-6"><div className="flex gap-3"><Icons.Ban /><div><h2 className="font-black">No blocked users in demo mode</h2><p className="mt-1 text-ink/70">Blocked users cannot request your activities or message you.</p></div></div></Card></PageShell>;
}
