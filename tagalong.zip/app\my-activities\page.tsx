import { ActivityCard } from "@/components/activity-card";
import { PageShell } from "@/components/ui";
import { activities } from "@/lib/demo-data";

export default function MyActivitiesPage() {
  return <PageShell><h1 className="text-4xl font-black">My activities</h1><div className="mt-6 grid gap-5 lg:grid-cols-3">{activities.filter((a) => a.hostId === "host-1").map((a) => <ActivityCard key={a.id} activity={a} />)}</div></PageShell>;
}
