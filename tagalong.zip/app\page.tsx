import Image from "next/image";
import { ActivityCard } from "@/components/activity-card";
import { Badge, ButtonLink, Card, Logo, SafetyNotice } from "@/components/ui";
import { activities } from "@/lib/demo-data";

const categories = [
  ["Entertainment and Errands", "Movies, coffee, restaurants, shopping, museums, local events, and everyday trips."],
  ["Help and Volunteer", "Non-medical companionship, community volunteering, grocery help, and technology assistance."],
  ["Adventure", "Hiking, cycling, camping, fishing, running, photography trips, and local exploration."]
];

export default function LandingPage() {
  return (
    <main className="bg-[#fbfbf7] text-ink">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-4 py-5 sm:px-6 lg:px-8">
        <Logo />
        <div className="flex gap-2">
          <ButtonLink href="/sign-in" variant="ghost">Sign in</ButtonLink>
          <ButtonLink href="/sign-up">Get started</ButtonLink>
        </div>
      </header>
      <section className="mx-auto grid max-w-7xl items-center gap-10 px-4 pb-14 pt-8 sm:px-6 lg:grid-cols-[1.05fr_.95fr] lg:px-8">
        <div>
          <Badge tone="wheat">18+ community activity platform</Badge>
          <h1 className="mt-5 max-w-3xl text-5xl font-black leading-[1.02] tracking-normal sm:text-7xl">Do more together.</h1>
          <p className="mt-5 max-w-2xl text-xl leading-8 text-ink/75">Find trusted people nearby for movies, errands, volunteering, outdoor activities, and everyday moments.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonLink href="/sign-up">Join TAGALONG</ButtonLink>
            <ButtonLink href="/demo" variant="ghost">Investor demo</ButtonLink>
          </div>
        </div>
        <div className="relative">
          <div className="absolute -left-4 top-8 hidden rounded-2xl bg-mint p-4 font-bold shadow-soft sm:block">Nearby posts, not dating profiles</div>
          <ActivityCard activity={activities[2]} />
        </div>
      </section>
      <section className="bg-white py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-4 md:grid-cols-3">
            {categories.map(([title, body]) => (
              <Card key={title}><h2 className="text-xl font-black">{title}</h2><p className="mt-3 text-sm leading-6 text-ink/70">{body}</p></Card>
            ))}
          </div>
        </div>
      </section>
      <section className="mx-auto grid max-w-7xl gap-8 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:px-8">
        <div>
          <h2 className="text-3xl font-black">A clear workflow from discovery to chat</h2>
          <div className="mt-6 grid gap-3">
            {["Browse nearby public activities", "Review the host profile and safety details", "Send a join request", "Host accepts or declines", "Accepted participants chat in-app"].map((step, index) => (
              <div key={step} className="flex gap-3 rounded-2xl bg-white p-4 shadow-sm"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-ink text-sm font-black text-white">{index + 1}</span><span className="font-semibold">{step}</span></div>
            ))}
          </div>
        </div>
        <div className="space-y-4">
          <h2 className="text-3xl font-black">Trust and safety</h2>
          <div className="mt-4"><SafetyNotice help /></div>
          <Card>
            <h2 className="text-2xl font-black">Community impact</h2>
            <p className="mt-3 leading-7 text-ink/70">TAGALONG is designed for useful companionship: more people attending local events, safer-feeling outdoor plans, and easier ways to volunteer with neighbors.</p>
          </Card>
        </div>
      </section>
      <section className="bg-mint py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-black">Example activities</h2>
          <div className="mt-6 grid gap-5 lg:grid-cols-3">
            {activities.slice(0, 3).map((activity) => <ActivityCard key={activity.id} activity={activity} />)}
          </div>
        </div>
      </section>
      <section className="mx-auto grid max-w-7xl items-center gap-8 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:px-8">
        <div className="rounded-[2rem] bg-ink p-5 shadow-soft">
          <div className="mx-auto max-w-xs rounded-[2rem] bg-[#fbfbf7] p-4">
            <Image src="/activity/phone.svg" alt="TAGALONG mobile mockup" width={360} height={640} className="rounded-[1.5rem]" />
          </div>
        </div>
        <div>
          <h2 className="text-3xl font-black">Built for an MVP demo</h2>
          <p className="mt-4 leading-7 text-ink/70">Demo mode includes seeded profiles, activity posts, requests, messages, notifications, reports, and a guided investor walkthrough without paid services.</p>
          <blockquote className="mt-6 rounded-2xl bg-white p-5 text-sm leading-6 shadow-sm">Sample testimonial: “TAGALONG made it easier to find someone nearby for a museum afternoon without the pressure of a dating app.”</blockquote>
        </div>
      </section>
      <footer className="border-t border-ink/10 bg-white px-4 py-8">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <Logo />
          <div className="flex flex-wrap gap-4 text-sm font-semibold text-ink/70">
            <a href="/privacy">Privacy</a><a href="/settings">Terms</a><a href="/safety">Safety</a><a href="mailto:hello@example.test">Contact</a>
          </div>
        </div>
      </footer>
    </main>
  );
}
