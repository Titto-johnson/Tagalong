import { ButtonLink, PageShell } from "@/components/ui";

export default function NotFound() {
  return (
    <PageShell narrow>
      <div className="py-20 text-center">
        <h1 className="text-5xl font-black">Page not found</h1>
        <p className="mt-4 text-ink/70">This TAGALONG page may have moved or the activity may no longer be public.</p>
        <div className="mt-8"><ButtonLink href="/home">Back to discovery</ButtonLink></div>
      </div>
    </PageShell>
  );
}
