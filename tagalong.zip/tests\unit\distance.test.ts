import { describe, expect, it } from "vitest";
import { milesBetween } from "@/lib/distance";

describe("milesBetween", () => {
  it("returns zero for identical coordinates", () => {
    expect(milesBetween({ latitude: 30.2672, longitude: -97.7431 }, { latitude: 30.2672, longitude: -97.7431 })).toBe(0);
  });

  it("calculates a reasonable Austin to Round Rock distance", () => {
    const miles = milesBetween({ latitude: 30.2672, longitude: -97.7431 }, { latitude: 30.5083, longitude: -97.6789 });
    expect(miles).toBeGreaterThan(15);
    expect(miles).toBeLessThan(20);
  });
});
