import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs";

const prisma = new PrismaClient();

const cities = [
  ["Austin, TX", 30.2672, -97.7431],
  ["Round Rock, TX", 30.5083, -97.6789],
  ["Cedar Park, TX", 30.5052, -97.8203],
  ["San Marcos, TX", 29.8833, -97.9414]
] as const;

const names = ["Maya Chen", "Jordan Lee", "Sam Rivera", "Nina Patel", "Owen Brooks", "Ari Morgan", "Riley Smith", "Elena Torres", "Priya Shah", "Caleb Ross", "Tessa Grant", "Noah Kim"];

const activityTypes = [
  ["ENTERTAINMENT_ERRANDS", "Movie", "Indie movie meetup"],
  ["ENTERTAINMENT_ERRANDS", "Coffee", "Coffee and sketchbooks"],
  ["ENTERTAINMENT_ERRANDS", "Museum", "Saturday museum walk"],
  ["ENTERTAINMENT_ERRANDS", "Grocery trip", "Recipe-focused grocery run"],
  ["ENTERTAINMENT_ERRANDS", "Local event", "Outdoor music evening"],
  ["HELP_VOLUNTEER", "Technology assistance", "Community phone setup help"],
  ["HELP_VOLUNTEER", "Grocery assistance", "Volunteer grocery shelf sorting"],
  ["HELP_VOLUNTEER", "Community volunteering", "Park cleanup volunteer team"],
  ["HELP_VOLUNTEER", "Non-medical companionship", "Library conversation hour"],
  ["HELP_VOLUNTEER", "Picking up essentials", "Donation pantry packing"],
  ["ADVENTURE", "Hiking", "Greenbelt morning hike"],
  ["ADVENTURE", "Cycling", "Easy neighborhood cycle"],
  ["ADVENTURE", "Running", "Lake loop jog"],
  ["ADVENTURE", "Photography trip", "Golden hour photo walk"],
  ["ADVENTURE", "Camping", "Beginner campsite planning meetup"],
  ["ADVENTURE", "Fishing", "Quiet pier fishing morning"],
  ["ENTERTAINMENT_ERRANDS", "Restaurant", "New ramen spot dinner"],
  ["HELP_VOLUNTEER", "Community volunteering", "Food bank packing shift"],
  ["ADVENTURE", "Sports", "Public pickleball doubles"],
  ["ENTERTAINMENT_ERRANDS", "Casual walk", "After-work neighborhood walk"]
] as const;

async function main() {
  await prisma.$transaction([
    prisma.adminAction.deleteMany(),
    prisma.safetyAcknowledgment.deleteMany(),
    prisma.verification.deleteMany(),
    prisma.block.deleteMany(),
    prisma.report.deleteMany(),
    prisma.review.deleteMany(),
    prisma.savedActivity.deleteMany(),
    prisma.notification.deleteMany(),
    prisma.message.deleteMany(),
    prisma.conversationMember.deleteMany(),
    prisma.conversation.deleteMany(),
    prisma.activityParticipant.deleteMany(),
    prisma.activityRequest.deleteMany(),
    prisma.activity.deleteMany(),
    prisma.profile.deleteMany(),
    prisma.session.deleteMany(),
    prisma.account.deleteMany(),
    prisma.user.deleteMany()
  ]);

  const passwordHash = await hash("Password123!", 12);
  const users = await Promise.all(
    names.map((name, index) => {
      const city = cities[index % cities.length];
      return prisma.user.create({
        data: {
          name,
          email: index === 0 ? "participant@tagalong.test" : index === 1 ? "host@tagalong.test" : `${name.toLowerCase().replaceAll(" ", ".")}@example.test`,
          passwordHash,
          role: index === 11 ? "ADMIN" : "USER",
          profile: {
            create: {
              displayName: name,
              age: 24 + index,
              biography: `${name} is a fictional TAGALONG demo member who prefers clear plans, public places, and friendly everyday activities.`,
              approximateCity: city[0],
              latitude: city[1] + index * 0.004,
              longitude: city[2] - index * 0.004,
              interests: ["coffee", "volunteering", "walking", index % 3 === 0 ? "hiking" : "local events"],
              languages: index % 2 === 0 ? ["English", "Spanish"] : ["English"],
              availability: index % 2 === 0 ? ["Weeknights", "Saturday mornings"] : ["Weekends", "Evenings"],
              preferredCategories: ["ENTERTAINMENT_ERRANDS", "HELP_VOLUNTEER", "ADVENTURE"],
              accessibilityInformation: "Prefers public, well-lit, step-free meeting areas when available."
            }
          },
          verifications: { create: { type: "email", status: "verified" } },
          safetyAcknowledgments: { create: { version: "mvp-2026-07" } }
        }
      });
    })
  );

  const activities = await Promise.all(
    activityTypes.map((entry, index) => {
      const category = entry[0];
      const city = cities[index % cities.length];
      const isAdventure = category === "ADVENTURE";
      return prisma.activity.create({
        data: {
          hostId: users[(index % (users.length - 1)) + 1].id,
          category,
          activityType: entry[1],
          title: entry[2],
          description: category === "HELP_VOLUNTEER"
            ? "A fictional non-medical community activity in a public setting. This does not involve emergencies, medication, childcare, transportation services, or financial transactions."
            : "A fictional public activity for meeting nearby people with simple expectations, clear timing, and respectful boundaries.",
          startsAt: new Date(Date.UTC(2026, 7, 2 + index, 18, 0, 0)),
          approximateLocationLabel: city[0],
          latitude: city[1] + index * 0.003,
          longitude: city[2] - index * 0.003,
          maximumParticipants: 2 + (index % 6),
          costType: index % 4 === 0 ? "PAID" : "FREE",
          accessibilityDetails: "Public location; check the venue for detailed accommodations.",
          equipmentDetails: isAdventure ? "Water, weather-appropriate clothing, and any personal safety essentials." : null,
          difficulty: isAdventure ? (index % 2 === 0 ? "MODERATE" : "EASY") : null,
          durationMinutes: isAdventure ? 120 + index * 10 : null,
          safetyNotes: isAdventure ? "Meet at a public trailhead, stay together, and turn back if weather conditions change." : "Meet in a public place and use in-app messaging before sharing exact details."
        }
      });
    })
  );

  for (let i = 0; i < 6; i += 1) {
    await prisma.activityRequest.create({ data: { activityId: activities[i].id, requesterId: users[0].id, introduction: "I am interested in joining and can meet in the public area first.", status: i % 2 === 0 ? "PENDING" : "ACCEPTED" } });
    if (i % 2 === 1) {
      await prisma.activityParticipant.create({ data: { activityId: activities[i].id, userId: users[0].id } });
      const conversation = await prisma.conversation.create({ data: { activityId: activities[i].id } });
      await prisma.conversationMember.createMany({ data: [{ conversationId: conversation.id, userId: users[0].id }, { conversationId: conversation.id, userId: activities[i].hostId }] });
      await prisma.message.createMany({ data: [{ conversationId: conversation.id, senderId: activities[i].hostId, body: "Welcome. Let's keep the plan public and simple." }, { conversationId: conversation.id, senderId: users[0].id, body: "Thanks. I will meet at the posted public location." }] });
    }
  }

  await prisma.savedActivity.createMany({ data: activities.slice(0, 4).map((activity) => ({ userId: users[0].id, activityId: activity.id })) });
  await prisma.notification.createMany({ data: [{ userId: users[0].id, title: "Request accepted", body: "Your request was accepted for a sample activity." }, { userId: users[1].id, title: "New join request", body: "Maya requested to join your activity." }] });
  await prisma.review.createMany({ data: [{ authorId: users[0].id, subjectId: users[1].id, activityId: activities[1].id, rating: 5, body: "Clear plans and respectful communication." }, { authorId: users[2].id, subjectId: users[0].id, activityId: activities[2].id, rating: 5, body: "Arrived on time and kept safety expectations clear." }] });
  const report = await prisma.report.create({ data: { reporterId: users[0].id, reportedUserId: users[4].id, activityId: activities[3].id, category: "Unsafe activity", details: "Fictional report for dashboard review.", status: "OPEN" } });
  await prisma.adminAction.create({ data: { actorId: users[11].id, reportId: report.id, action: "queued_review", notes: "Sample moderation audit trail entry." } });
}

main().finally(async () => prisma.$disconnect());
