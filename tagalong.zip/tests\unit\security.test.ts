import { describe, expect, it } from "vitest";
import { activitySchema, containsProhibitedHelpRequest } from "@/lib/security";

describe("safety validation", () => {
  it("blocks prohibited help requests", () => {
    expect(containsProhibitedHelpRequest("Need someone to handle prescription medication")).toBe(true);
  });

  it("requires adventure safety details", () => {
    const result = activitySchema.safeParse({
      category: "ADVENTURE",
      activityType: "Hiking",
      title: "Morning trail hike",
      description: "A public trail walk with clear meeting plans and respectful pacing.",
      startsAt: new Date("2026-08-01T14:00:00.000Z"),
      approximateLocationLabel: "Austin, TX",
      latitude: 30.2,
      longitude: -97.7,
      maximumParticipants: 4,
      costType: "FREE"
    });
    expect(result.success).toBe(false);
  });
});
