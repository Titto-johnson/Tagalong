import { Card, PageShell } from "@/components/ui";

export default function SettingsPage() {
  return <PageShell narrow><h1 className="text-4xl font-black">Settings</h1><div className="mt-6 space-y-4">{["Email and password", "Session management", "Data export placeholder", "Account deletion", "Notification preferences"].map((item) => <Card key={item}><h2 className="text-xl font-black">{item}</h2><p className="mt-2 text-ink/70">Manage {item.toLowerCase()} for your TAGALONG account.</p></Card>)}</div></PageShell>;
}
