import { AuthForm } from "@/components/forms";
import { PageShell } from "@/components/ui";

export default function SignInPage() {
  return <PageShell narrow><AuthForm mode="sign-in" /></PageShell>;
}
