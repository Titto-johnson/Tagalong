import { ActivityCard } from "@/components/activity-card";
import { PageShell } from "@/components/ui";
import { activities } from "@/lib/demo-data";

export default function SavedActivitiesPage() {
  return <PageShell><h1 className="text-4xl font-black">Saved activities</h1><div className="mt-6 grid gap-5 lg:grid-cols-3">{activities.slice(0, 2).map((a) => <ActivityCard key={a.id} activity={a} />)}</div></PageShell>;
}
