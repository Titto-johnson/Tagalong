# Validation

This file records commands run for this workspace. A command is marked passed only after it executes successfully.

| Command | Status | Notes |
| --- | --- | --- |
| `npm install` | Failed | `npm` is not available on this machine's PATH. |
| `pnpm install` | Passed | Required bundled Node on PATH and explicit build-script allowlist in `pnpm-workspace.yaml`. |
| `pnpm exec prisma validate` | Passed | Ran with placeholder local `DATABASE_URL`. |
| `pnpm exec prisma migrate dev --name init --skip-seed` | Failed | No PostgreSQL server was reachable at `localhost:5432`; Docker is not installed on this machine. |
| `pnpm run db:seed` | Failed | No PostgreSQL server was reachable at `localhost:5432`; seed script could not connect. |
| `pnpm run lint` | Passed | ESLint completed with no warnings or errors. |
| `pnpm run typecheck` | Passed | TypeScript strict validation completed. |
| `pnpm run test` | Passed | 2 unit test files, 4 tests passed. |
| `pnpm run dev` | Passed | Local Next.js dev server started at `http://localhost:3100`. |
| `POST /api/demo-auth` | Passed | Demo sign-in redirects to `/home`; demo sign-up redirects to `/onboarding`. |
| `pnpm exec playwright install chromium` | Passed | Installed Chromium browser for e2e validation. |
| `pnpm run test:e2e` | Passed | 2 Playwright smoke tests passed on desktop Chromium and mobile viewport. |
| `pnpm run build` | Passed | Production build compiled and generated 33 app pages/routes. |
