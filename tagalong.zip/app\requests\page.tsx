import { Badge, ButtonLink, Card, PageShell } from "@/components/ui";
import { requests } from "@/lib/demo-data";

export default function RequestsPage() {
  return (
    <PageShell>
      <h1 className="text-4xl font-black">Join-request management</h1>
      <div className="mt-6 grid gap-4">
        {requests.map((request) => (
          <Card key={request.id}>
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div><Badge tone={request.status === "ACCEPTED" ? "mint" : "wheat"}>{request.status}</Badge><h2 className="mt-3 text-xl font-black">{request.requester} wants to join {request.activityTitle}</h2><p className="mt-2 text-ink/70">{request.intro}</p></div>
              <div className="flex gap-2"><button className="rounded-full bg-ink px-4 py-2 text-sm font-bold text-white">Accept</button><button className="rounded-full bg-white px-4 py-2 text-sm font-bold ring-1 ring-ink/10">Decline</button></div>
            </div>
          </Card>
        ))}
      </div>
      <div className="mt-6"><ButtonLink href="/messages">Open accepted conversations</ButtonLink></div>
    </PageShell>
  );
}
