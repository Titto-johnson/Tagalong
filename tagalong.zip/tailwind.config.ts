import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#17211d",
        moss: "#53735b",
        mint: "#d9f2de",
        coral: "#f36f45",
        sky: "#dbeafe",
        wheat: "#fff4cf"
      },
      boxShadow: {
        soft: "0 18px 60px rgba(23, 33, 29, 0.12)"
      }
    }
  },
  plugins: []
};

export default config;
