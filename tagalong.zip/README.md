# TAGALONG

TAGALONG is a production-style MVP for finding nearby companions for everyday activities, volunteering, errands, and outdoor adventures. It is intentionally not a dating product.

## Main Features

- Landing page, onboarding, safety guidelines, discovery feed, category pages, activity details, create/edit activity, requests, profiles, messaging, notifications, saved activities, settings, privacy, blocked users, reporting, moderation, custom 404, and error state.
- Auth.js email/password authentication with secure password hashing and optional Google sign-in when environment variables are present.
- Prisma/PostgreSQL schema for users, profiles, activities, requests, participants, conversations, messages, notifications, saved activities, reviews, reports, blocks, verifications, safety acknowledgments, and admin actions.
- Approximate-location discovery with distance calculations and no public exact addresses.
- MVP trust and safety controls: 18+ confirmation, guideline acknowledgment, report/block flows, prohibited help-category validation, adventure safety fields, and moderation audit trail.
- Demo mode with seeded fictional users, activities, requests, conversations, notifications, reviews, and reports.

## Technology Stack

Next.js, React, TypeScript, Tailwind CSS, Auth.js, Prisma ORM, PostgreSQL, Zod, bcryptjs, Vitest, Playwright, ESLint, Docker.

## Architecture Summary

The app uses the Next.js App Router. Reusable UI lives in `components/`, validation/security helpers in `lib/`, REST route handlers in `app/api/`, Prisma schema and seed data in `prisma/`, and automated tests in `tests/`. Server handlers always derive identity from the session or development demo mode rather than trusting client-provided user IDs.

## Local Installation

```bash
pnpm install
cp .env.example .env
pnpm exec prisma migrate dev
pnpm run db:seed
pnpm run dev
```

Open `http://localhost:3100`.

## Environment Variables

Use `.env.example` as the source of required keys. Do not commit `.env`.

- `DATABASE_URL`: PostgreSQL connection string.
- `AUTH_SECRET`: long random secret for Auth.js.
- `AUTH_URL`: local or deployed application URL.
- `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`: optional Google sign-in.
- `NEXT_PUBLIC_DEMO_MODE`: set to `true` locally to show demo shortcuts.

## Demo Accounts

Development-only fictional accounts loaded by the seed script:

- Host: `host@tagalong.test` / `Password123!`
- Participant: `participant@tagalong.test` / `Password123!`

## Development Commands

```bash
pnpm run dev
pnpm run lint
pnpm run typecheck
pnpm run test
pnpm run test:e2e
pnpm run build
pnpm run db:migrate
pnpm run db:seed
```

## Database Setup

Start PostgreSQL locally or use Docker:

```bash
docker compose up postgres
pnpm exec prisma migrate dev
pnpm run db:seed
```

## Docker

```bash
docker compose up --build
```

## Testing

Unit tests cover distance calculation and safety validation. The Playwright smoke test verifies the landing page and core CTA rendering on desktop and mobile projects.

## Deployment

Deploy to Vercel with a PostgreSQL-compatible provider such as Neon or Supabase. Set the environment variables in the hosting dashboard, run Prisma migrations against the hosted database, and keep `NEXT_PUBLIC_DEMO_MODE` disabled for production.

## Security Notes

TAGALONG stores password hashes, not plaintext passwords. Prisma guards SQL access, Zod validates incoming payloads, sensitive routes use authorization checks, and exact private addresses are not publicly displayed. Help-category posts block obvious prohibited regulated-service requests. This MVP does not implement identity verification, background checks, emergency response, insurance, medical care, caregiving, or transportation services.

## Known MVP Limitations

- Messaging uses request/response APIs and can be polled; WebSockets are not included.
- The map is a mock OpenStreetMap-compatible local preview rather than a full tile integration.
- Demo UI forms are presentational in several screens; critical backend operations are implemented in API routes.
- Abuse prevention is in-memory rate limiting for the MVP and should move to durable storage in production.
- Data export is documented as a placeholder.

## Future Roadmap

- MVP: discovery, posting, requests, profiles, messaging, moderation.
- Phase 2: stronger identity verification, group activities, recommendations.
- Phase 3: community partnerships, event integrations, reputation improvements.

## Repository Structure

```text
app/
components/
lib/
prisma/
public/
tests/
types/
middleware.ts
package.json
tsconfig.json
tailwind.config.ts
next.config.ts
playwright.config.ts
.env.example
.eslintrc.json
.gitignore
Dockerfile
docker-compose.yml
LICENSE
README.md
VALIDATION.md
```

## Screenshots

Add screenshots here after running the app locally:

- Landing page
- Discovery feed
- Activity details
- Messaging
- Admin moderation dashboard

## License

MIT. See `LICENSE`.
