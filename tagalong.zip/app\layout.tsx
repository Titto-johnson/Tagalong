import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "TAGALONG | Do more together",
  description: "Find trusted people nearby for movies, errands, volunteering, outdoor activities, and everyday moments.",
  openGraph: {
    title: "TAGALONG",
    description: "Do more together with nearby companions for everyday activities.",
    type: "website"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  );
}
