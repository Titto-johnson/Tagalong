import { expect, test } from "@playwright/test";

test("landing page presents TAGALONG and main CTA", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "Do more together." })).toBeVisible();
  await expect(page.getByRole("link", { name: /Join TAGALONG/ })).toBeVisible();
  await expect(page.getByText("Entertainment and Errands")).toBeVisible();
  await expect(page.getByText("Trust and safety", { exact: false })).toBeVisible();
});
